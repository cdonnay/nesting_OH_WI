2022 Ohio State House of Representatives Districts Plan (State Legislative District Lower [SLDL])

##Redistricting Data Hub (RDH) Retrieval Date
05/31/2022

##Sources
This dataset was retrieved from the Ohio Secretary of State at: https://www.ohiosos.gov/elections/ohio-candidates/district-maps/

##Processing
The RDH did not modify any of this data.

##Additional Notes
Enclosed in this zip file the shapefile file for Ohio's Senate Districts ("FEB_24_2022_HD_SHP.shp") and supporting files, a block equivalency file ("directive-2022-26_hd-bafs.xlsx"), and a PDF map ("ohiohouseofrepresentatives_2022-5-28.pdf").
For any additional questions, please email info@redistrictingdatahub.org