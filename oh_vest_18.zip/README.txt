2018 Ohio precinct and election results shapefile.

## RDH Date retrieval
04/13/2022

## Sources

Election results from the Ohio Secretary of State (https://www.sos.state.oh.us/elections/election-results-and-data/). 
Precinct shapefile from the U.S. Census Bureau's 2020 Redistricting Data Program final release. 
Note that some VTDs were relabeled to match precinct names and/or precinct codes in the November 2018 general election returns.

## Fields metadata

Vote Column Label Format
------------------------
Columns reporting votes follow a standard label pattern. One example is:
G16PREDCli
The first character is G for a general election, P for a primary, C for a caucus, R for a runoff, S for a special.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes
A## - Ballot amendment, where ## is an identifier
AGR - Commissioner of Agriculture
ATG - Attorney General
AUD - Auditor
CFO - Chief Financial Officer
CHA - Council Chairman
COC - Corporation Commissioner
COM - Comptroller
CON - State Controller
COU - City Council Member
CSC - Clerk of the Supreme Court
DEL - Delegate to the U.S. House
GOV - Governor
H## - U.S. House, where ## is the district number. AL: at large.
HOD - House of Delegates, accompanied by a HOD_DIST column indicating district number
HOR - U.S. House, accompanied by a HOR_DIST column indicating district number
INS - Insurance Commissioner
LAB - Labor Commissioner
LND - Commissioner of Public/State Lands
LTG - Lieutenant Governor
MAY - Mayor
MNI - State Mine Inspector
PSC - Public Service Commissioner
PUC - Public Utilities Commissioner
RGT - State University Regent
SAC - State Appeals Court
SBE - State Board of Education
SOC - Secretary of Commonwealth
SOS - Secretary of State
SPI - Superintendent of Public Instruction
SPL - Commissioner of School and Public Lands
SSC - State Supreme Court
TAX - Tax Commissioner
TRE - Treasurer
UBR - University Board of Regents/Trustees/Governors
USS - U.S. Senate

Party Codes
D and R will always represent Democrat and Republican, respectively.
See the state-specific notes for the remaining codes used in a particular file; note that third-party candidates may appear on the ballot under different party labels in different states.


## Fields


G18USSRREN - Jim Renacci (Republican Party)
G18USSDBRO - Sherrod Brown (Democratic Party)

G18GOVRDEW - Mike DeWine (Republican Party)
G18GOVDCOR - Richard Cordray (Democratic Party)
G18GOVLIRV - Travis M. Irvine (Libertarian Party)
G18GOVGGAD - Constance Gadell-Newton (Green Party)

G18ATGRYOS - Dave Yost (Republican Party)
G18ATGDDET - Dteve Dettelbach (Democratic Party)

G18AUDRFAB - Keith Faber (Republican Party)
G18AUDDSPA - Zach Space (Democratic Party)
G18AUDLCOO - Robert C. Coogan (Libertarian Party)

G18SOSRLAR - Frank LaRose (Republican Party)
G18SOSDCLY - Kathleen Clyde (Democratic Party)
G18SOSLNAN - Dustin R. Nanna (Libertarian Party)

G18TRERSPR - Robert Sprague (Republican Party)
G18TREDRIC - Rob Richardson (Democratic Party)

## Processing Steps

The following counties include adjustments to account for corporate annexations that are not specified below by precinct: Adams, Athens, Auglaize, Brown, Butler, Defiance, Franklin, Geauga, Guernsey, Licking, Lorain, Madison, Marion, Miami, Ottawa, Pickaway, Shelby, Stark, Tuscarawas, Warren, Wayne, Wyandot.

This includes the amended Miami County results from January 2019, which reflect 6282 early votes that had gone uncounted.

The following additional revisions were made to match the 2018 precinct boundaries:

Athens: Adjust Athens 4-4/4-5, Nelsonville 1/2/3/4
Brown: Adjust Perry Twp South/Villages
Butler: Adjust Hamilton 22/24, Oxford 6/11, Trenton 5/7, West Chester 28/39
Champaign: Adjust Union N/S
Clark: Align New Carlisle, Springfield precincts with county maps
Clermont: Reverse unincorporation of Amelia and Newtonsville
Coshocton: Split Coshocton 3-B/C, 4-B/C
Crawford: Move eastern Polk Twp from Galion 1B to western Polk Twp
Cuyahoga: Adjust Olmsted Twp D/F/H
Delaware: Merge Berlin B/F, Concord F/J, Delaware 3-F/H, Orange G/U, Powell K into G/I, Westerville A/I
Fairfield: Realign precincts in Columbus City, Lancaster Ward 1, Ward 2, Ward 6; Merge Pickerington K/O, Pickerington N into F/L; Adjust Bloom A/B, Lancaster 4-B/C, Pickerington J/K, Violet B/C, I/J
Franklin: Merge Dub 1-I into Dub 1-A/F, Cols 08-A/H, 08-B/G, 12-D/E, 30-A/E, 33-C/J, 45-K/O, 46-G/M, 52-C/H, 73-J/M, 75-E/I, 79-D/E, 82-F/N, 82-I/O, 83-C/J, 83-F/I, Grove City 1-E/G, 2-E/G, Jefferson E/J, Reyns 2-A/G, Worth 3-A/D
Fulton: Split Amboy/Metamora, Fayette/Gorham, Lyons/Royalton, Swancreek West 1/2, Swanton 1/2, Swanton 3/4, York N/S
Greene: Adjust Bath 277/Fairborn 226/Xenia 351
Hamilton: Merge Blue Ash 4-A/B, Norwood 1-A/C, Cincinnati 6-E into 6-A/B, 11-D into 11-A/B/C; Adjust Blue Ash 1-B/2-A/3-B/4-A, Cincinnati 23-A/D, 23-I/P, 25-F/K, Cleves A/Whitewater A, Colerain BB/F/H, Delhi A/B, Loveland D/Symmes C/K, Miami B/D/G, Whitewater A/C; Realign Cincinnati/Green B
Knox: Merge Brinkhaven/Union
Lake: Merge Concord B/O; Adjust Painesville A/K, Willoughby Hills CC/DD
Lorain: Merge N. Ridgeville 3-F/H, N. Ridgeville 1-E into 1-B/D
Medina: Merge Brunswick City 1-F into 1-C/D, Montville Twp H into A/B, Montville Twp I into A/C/E, York Twp C into A/B; Adjust Brunswick City 1-A/B, Wadsworth City 1-D/Sharon D, Wadsworth City 2-D/Twp C
Pickaway: Merge Commercial Point East/West; Add Circleville 1-D; Align Circleville wards with city map
Putnam: Merge Glandorf/Ottawa Twp West
Richland: Adjust Ontario 3/4
Stark: Split Alliance 3-A/C, Canton 2-D/F, 2-E/G, 4-D/E, Massillon 4-A/B, 5-B/C, 7-B/D, 7-H/I, Lake 10/12, Paris A/B, Plain 7/13, Plain 22/23; Merge Lake B into Lake A/15, Lawrence 6 into Lawrence 1/3; Adjust Jackson 6/22, N. Canton 2-A/B, Perry 4/16, Plain 8/29/30
Summit: Adjust Coventry D/G, Hudson 1-B/3-C, South Lebanon A/B, Springfield F/J
Union: Merge Jerome 3/6, Marysville 1/2, Marysville 4 into 3/11, Marysville 15 into 4/9
Warren: Split Springboro City 4-B/D, Deerfield W from Deerfield AA/X, Mason City U from Mason City N/T; Merge Clearcreek B/N, Hamilton A/U, D/T, Turtlecreek L into Turtlecreek A/F, Mason City Z into Mason City F/Deerfield E/Union A; Adjust Carlisle 2-A/3-A, South Lebanon A/B, Springboro 1-B/C, Turtlecreek F/K
Wood: Replace Bloom, Milton, Montgomery, Perry, Portage precincts with 2019 VTDs
Wyandot: Split Sycamore Twp/Village